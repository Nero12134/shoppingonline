const MyConstants = {
    DB_SERVER: 'quoc.qbpw7rk.mongodb.net',
    DB_USER: 'quoctran7056',
    DB_PASS: '25062002',
    DB_DATABASE: 'shoppingonline',
    EMAIL_USER: 'quoctran7056@gmail.com', // Microsoft mail service
    EMAIL_PASS: 'pjlfajgpdlpdunty',
    JWT_SECRET: 'quockk',
    JWT_EXPIRES: '720000000', // in milliseconds
  };
  module.exports = MyConstants;